#include <Arduino.h>
#include <ESP32Servo.h>
#include <Stepper.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <ArduinoJson.h>

WiFiServer server(80);
WiFiUDP udp;
const unsigned int udpPort = 8888;
char incomingPacket[256];
const char* ssid     = "PotatoSpot";
const char* password = "mathu0331";

static const int servoPin = 14;  // Changed from 13 to avoid conflict with AccelStepper
static const int servo2Pin = 47;
static const int gobilda1TurnPin = 13;  // 1 turn gobilda
static const int gobilda5TurnPin = 41;  // 5 turn gobilda, 16 

Servo servo1;
Servo servo2;
Servo gobilda1Turn;
Servo gobilda5Turn;

// Position array from UDP POT data
int pos[6] = {0, 0, 0, 0, 0, 0};

// Variables for non-blocking control
unsigned long lastServoUpdate = 0;
int servoPos = 0;
int servoDirection = 1;

int servo2Pos = 0;
int servo2Direction = 1;

unsigned long lastStepperUpdate = 0;
int stepperPos = 0;
bool stepperDirection = true;

// put function declarations here:
void updateServo(Servo &servo, int &pos, int &direction, const char* name);


// Set LED_BUILTIN if it is not defined by Arduino framework
#ifndef LED_BUILTIN
    #define LED_BUILTIN 2
#endif

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("\nESP32-S3 UDP Receiver");
  
  // Attach servos
  servo1.attach(servoPin);
  servo2.attach(servo2Pin);
  gobilda1Turn.attach(gobilda1TurnPin);
  gobilda5Turn.attach(gobilda5TurnPin);

  // Connect to WiFi
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  
  server.begin();
  udp.begin(udpPort);
  
  Serial.printf("UDP server started on port %d\n", udpPort);
  Serial.println("Ready to receive data!\n");
}

void loop() {
  // Check for UDP packets
  int packetSize = udp.parsePacket();
  
  if (packetSize) {
    int len = udp.read(incomingPacket, sizeof(incomingPacket) - 1);
    if (len > 0) {
      incomingPacket[len] = '\0';
    }
    
    // Parse JSON
    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(doc, incomingPacket);
    
    if (!error && doc.containsKey("pots")) {
      JsonArray array = doc["pots"];
      
      if (array.size() >= 6) {
        for (int i = 0; i < 6; i++) {
          pos[i] = array[i];
        }
        
        // Print received values
        Serial.print("pos[] = [");
        for (int i = 0; i < 6; i++) {
          Serial.print(pos[i]);
          if (i < 5) Serial.print(", ");
        }
        Serial.print("]\n");
      }
    }
  }
  
  // Map POT values (0-270) to motor controls
  
  // Index 1: Gobilda 1 turn servo - map to angle (0-135)
  // int gobilda1Angle = map(pos[1], 0, 270, 0, 135);
  // Serial.printf("POS1: %d, Gobilda 1 turn angle: %d\n", pos[1], gobilda1Angle);
  // gobilda1Turn.write(gobilda1Angle);
  
  // Index 2: Gobilda 5 turn servo - map to angle (0-1800 for 5 turns)
  int gobilda5Angle = map(pos[2], 0, 270, 0, 180/5);
  // printf("POS2: %d, Gobilda 5 turn angle: %d\n", pos[2], gobilda5Angle);
  // gobilda5Turn.write(gobilda5Angle);
  
  // Index 4: Microservo 1 - map to angle (0-180)
  int servo1Angle = map(pos[4], 0, 270, 0, 180);
  servo1.write(servo1Angle);
  
  // Index 5: Microservo 2 - map to angle (0-180)
  int servo2Angle = map(pos[5], 0, 270, 0, 180);
  servo2.write(servo2Angle);
}

