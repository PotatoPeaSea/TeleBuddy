#!/usr/bin/env python3
"""Simple serial receiver for Arduino potentiometer output with WebSocket forwarding.

Usage: python reciever.py [PORT] [BAUD] [ESP32_IP]
If PORT is not given, you'll be prompted to choose from available ports.
If ESP32_IP is provided, potentiometer data will be sent to ws://ESP32_IP:81
"""

import sys
import time
import json

try:
    import serial
    from serial.tools import list_ports
except Exception:
    print("pyserial is required. Install with: pip install pyserial")
    sys.exit(1)

try:
    import websocket
except Exception:
    print("websocket-client is required. Install with: pip install websocket-client")
    sys.exit(1)


def choose_port():
    """Prompt user to select a serial port or use command-line argument."""
    # Get list of available serial ports
    ports = list(list_ports.comports())
    
    if not ports:
        print("No serial ports found.")
        sys.exit(1)
    
    # If port specified in command line, use it
    if len(sys.argv) > 1:
        return sys.argv[1]
    
    # Otherwise, show menu and let user choose
    print("Available ports:")
    for i, p in enumerate(ports):
        print(f"  {i}: {p.device} - {p.description}")
    
    try:
        idx = int(input("Select port index [0]: ") or 0)
    except Exception:
        idx = 0
    
    return ports[idx].device


def parse_potentiometer_line(line_str):
    """Parse a line like 'POT0:123 POT1:456 ...' into a dictionary.
    
    Args:
        line_str: String from serial port
        
    Returns:
        dict: Dictionary mapping pot names to values, e.g. {"POT0": "123", "POT1": "456"}
    """
    parts = line_str.split()
    values = {}
    
    for part in parts:
        if ":" in part:
            key, val = part.split(":", 1)
            values[key] = val
    
    return values


def format_output(values):
    """Format potentiometer values into a readable string.
    
    Args:
        values: dict mapping POT names to values
        
    Returns:
        str: Formatted output string
    """
    # Create list of all expected pot keys
    keys = [f"POT{i}" for i in range(6)]
    
    # Format each pot value, use "----" if missing
    output_parts = []
    for k in keys:
        val = values.get(k, "----")
        output_parts.append(f"{k}: {val:>4}")
    
    # Join with separator
    return " | ".join(output_parts)


def main():
    """Main loop: open serial port and continuously read/display pot values."""
    # Get port and baud rate
    port = choose_port()
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else 115200
    
    # Get ESP32 IP if provided (3rd argument)
    esp32_ip = sys.argv[3] if len(sys.argv) > 3 else None
    ws = None
    
    # Connect to ESP32 WebSocket server if IP provided
    if esp32_ip:
        ws_url = f"ws://{esp32_ip}:81"
        try:
            print(f"Connecting to ESP32 WebSocket at {ws_url}...")
            ws = websocket.WebSocket()
            ws.connect(ws_url, timeout=5)
            print(f"✓ Connected to ESP32 at {ws_url}")
        except Exception as e:
            print(f"Warning: Could not connect to ESP32 WebSocket: {e}")
            print("Continuing without WebSocket...")
            ws = None
    
    # Open serial connection
    try:
        ser = serial.Serial(port, baud, timeout=1)
    except Exception as e:
        print(f"Failed to open {port}: {e}")
        sys.exit(1)

    print(f"Listening on {port} @ {baud}")
    print("=" * 60)
    
    try:
        while True:
            # Read one line from serial
            line = ser.readline()
            if not line:
                continue
            
            # Decode bytes to string
            try:
                line_str = line.decode(errors="ignore").strip()
            except Exception:
                line_str = str(line)

            # Check if this is a potentiometer data line
            if "POT" in line_str:
                # Parse the potentiometer values
                values = parse_potentiometer_line(line_str) #returns dict 
                
                if values:
                    # Send to ESP32 via WebSocket if connected
                    if ws:
                        try:
                            # Convert string values to integers for the controlled arm
                            pot_array = [int(values.get(f"POT{i}", 0)) for i in range(6)/270]
                            
                            # Send as JSON: {"pots": [val0, val1, val2, val3, val4, val5]}
                            message = json.dumps({"pots": pot_array})
                            ws.send(message)
                        except Exception as e:
                            print(f"WebSocket send error: {e}")
                            # Try to reconnect
                            try:
                                ws.close()
                                ws = websocket.WebSocket()
                                ws.connect(f"ws://{esp32_ip}:81", timeout=5)
                                print("✓ WebSocket reconnected")
                            except:
                                ws = None
                                print("WebSocket disconnected")
                    
                    # Format and print the values
                    output = format_output(values)
                    print(output)
                else:
                    # Couldn't parse, just print raw
                    print(line_str)
            else:
                # Not a pot line, print as-is
                print(line_str)
        
                
    except KeyboardInterrupt:
        print("\nExiting")
    finally:
        if ws:
            ws.close()
        ser.close()


if __name__ == "__main__":
    main()
