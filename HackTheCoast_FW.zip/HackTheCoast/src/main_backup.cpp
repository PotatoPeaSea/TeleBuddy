#include <Arduino.h>
#include <ESP32Servo.h>
#include <AccelStepper.h>

static const int servoPin = 14;  // Changed from 13 to avoid conflict

const int stepsPerRevolution = 2048 * 2; 
// ULN2003 Motor Driver Pins
#define IN1 19
#define IN2 18
#define IN3 5
#define IN4 17

// initialize the stepper library
AccelStepper myStepper(AccelStepper::FULL4WIRE, IN1, IN3, IN2, IN4);

Servo servo1;

// put function declarations here:
int myFunction(int, int);


// Set LED_BUILTIN if it is not defined by Arduino framework
#ifndef LED_BUILTIN
    #define LED_BUILTIN 2
#endif

void setup() {
  // put your setup code here, to run once:
  int result = myFunction(2, 3);
  // initialize LED digital pin as an output.
  pinMode(LED_BUILTIN, OUTPUT);

  Serial.begin(115200);
  servo1.attach(servoPin);

  // set the maximum speed and acceleration
  // myStepper.setMaxSpeed(1000 * 2);
  // myStepper.setAcceleration(500);
  // myStepper.setSpeed(200);
  // // initialize the serial port
  // Serial.begin(115200);
}

void loop() {
  // put your main code here, to run repeatedly:

  // // turn the LED on (HIGH is the voltage level)
  // digitalWrite(LED_BUILTIN, HIGH);
  // // wait for a second
  // delay(1000);
  // // turn the LED off by making the voltage LOW
  // digitalWrite(LED_BUILTIN, LOW);
  //  // wait for a second
  // delay(1000);

  // Servo
  for(int posDegrees = 0; posDegrees <= 180; posDegrees++) {
    servo1.write(posDegrees);
    Serial.println(posDegrees);
    delay(20);
  }

  for(int posDegrees = 180; posDegrees >= 0; posDegrees--) {
    servo1.write(posDegrees);
    Serial.println(posDegrees);
    delay(20);
  }
  

  // Stepper w/ steps per revolution
  // // step one revolution in one direction:
  // Serial.println("clockwise");
  // myStepper.moveTo(stepsPerRevolution);
  // myStepper.runToPosition();
  // delay(1000);

  // // step one revolution in the other direction:
  // Serial.println("counterclockwise");
  // myStepper.moveTo(0);
  // myStepper.runToPosition();
  // delay(1000);

  // Stepper continuous
  // myStepper.runSpeed();

}

// put function definitions here:
int myFunction(int x, int y) {
  return x + y;
}